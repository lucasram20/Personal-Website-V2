<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Lucas Ramirez</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/Logo.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">


</head>

<body>

  <!-- ======= Mobile nav toggle button ======= -->
  <i class="bi bi-list mobile-nav-toggle d-xl-none"></i>

  <!-- ======= Header ======= -->
  <header id="header">
    <div class="d-flex flex-column">

      <div class="profile">
        <img src="assets/img/Emman-img.png" alt="" class="img-fluid rounded-circle">
        <h1 class="text-light"><a href="index.html">Lucas Ramirez</a></h1>
        <div class="social-links mt-3 text-center">
          <a href="https://twitter.com/KaminariKokyu1" class="twitter" target="_blank"><i class="bx bxl-twitter"></i></a>
          <a href="#" class="facebook"><i class="bx bxl-facebook" target="_blank"></i></a>
          <a href="https://www.linkedin.com/in/lucas-emmanuel-ramirez-362b74253/" class="linkedin" target="_blank"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>

      <nav id="navbar" class="nav-menu navbar">
        <ul>
          <li><a href="#hero" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Home</span></a></li>
          <li><a href="#about" class="nav-link scrollto"><i class="bx bx-user"></i> <span>About</span></a></li>
          <li><a href="#resume"  class="btn btn-color-2" onclick="window.open('./CV/Resume.pdf')"><i class="bx bx-file-blank"></i> <span>CV</span></a></li>
          <li><a href="#portfolio" class="nav-link scrollto"><i class="bx bx-book-content"></i> <span>Hobbies</span></a></li>
          <li><a href="#contact" class="nav-link scrollto"><i class="bx bx-envelope"></i> <span>Contact</span></a></li>
          <li><a href="#" onclick="exitFunction()" class="nav-link scrollto"><i class="bx bx-exit"></i> <span>Exit</span></a>
</li>

        <script>
        function exitFunction() {
          // Perform exit action here
          // For example, you can redirect the user to the homepage
          window.location.href = "/MyWebsite/Log_Reg/log.php";
        }
        </script>


        </ul>
      </nav><!-- .nav-menu -->
    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="hero-container" data-aos="fade-in">
      <h1>Lucas Ramirez</h1>
      <p>Hello there! <span class="typed" data-typed-items="Welcome to my Personal Website."></span></p>
    </div>
  </section><!-- End Hero -->
  

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>About</h2>
          <p>My name is Lucas Emmanuel B. Ramirez, currently taking a BSIT-MI course in National University Fairview Branch (NU-FV).</p>
        </div>

        <div class="row">
          <div class="col-lg-4" data-aos="fade-right">
            <img src="assets/img/Emman-img.png" class="img-fluid" alt="">
          </div>
          <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
            <h3>Aspiring Game Developer.</h3> 
            <p class="fst-italic">
              My Info.
            </p>
            <div class="row">
              <div class="col-lg-6">
                <ul>
                  <li><i class="bi bi-chevron-right"></i> <strong>Birthday:</strong> <span>20, October 2003</span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Email:</strong> <span>manuelram858@gmail.com</span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Nationality:</strong> <span>Filipino</span></li>
                </ul>
              </div>
              <div class="col-lg-6">
                <ul>
                  <li><i class="bi bi-chevron-right"></i> <strong>Age:</strong> <span>20</span></li>
                </ul>
              </div>
            </div>
            <p>
              I am more of introverted type person but when I get close to people that I'm comfortable with, my extroverted side stands out. And I am a carefree person that loves playing games, watching movies, reading mangas and novels. You can see more info about my Hobbies in the Hobbies section.
            </p>
          </div>
        </div>

      </div>
    </section><!-- End About Section -->

    <!-- ======= Certificates Section ======= -->
    <section id="facts" class="facts">
      <div class="container">

        <div class="section-title">
          <h2>Certificates</h2>
          <p> Here are some of my certificates:</p>
        </div>

        <div class="row no-gutters">

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up">
            <div class="count-box">
              <i class="bi bi-emoji-smile"></i>
              <p><strong>IBM SKILLS BUILD</strong> ✔ </p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="count-box">
              <i class="bi bi-emoji-smile"></i>
              <p><strong>Oracle Cloud Infrastructure</strong> ✔ </p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="200">
            <div class="count-box">
              <i class="bi bi-emoji-smile"></i>
              <p><strong>EXCEL</strong> ✔ </p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="300">
            <div class="count-box">
              <i class="bi bi-emoji-smile"></i>
              <p><strong>Powerpoint</strong> ✔ </p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Certificates Section -->

    <!-- ======= Skills Section ======= -->
    <section id="skills" class="skills section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Skills</h2>
          <p>Here are some of my skills.</p>
        </div>

        <div class="row skills-content">

          <div class="col-lg-6" data-aos="fade-up">

            <div class="progress">
              <span class="skill">HTML <i class="val">75%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">CSS <i class="val">50%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">JavaScript <i class="val">75%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>

          </div>

          <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">

            <div class="progress">
              <span class="skill">PHP <i class="val">60%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">GDScript <i class="val">70%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>

            <div class="progress">
              <span class="skill">Editing <i class="val">70%</i></span>
              <div class="progress-bar-wrap">
                <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section><!-- End Skills Section -->


    <!-- ======= Hobbies Section ======= -->
    <section id="portfolio" class="portfolio section-bg">
      <div class="container">

        <div class="section-title">
          <h2>Hobbies</h2>
          <p>Below are the gallery pictures of my hobbies:</p>
        </div>

        <div class="row" data-aos="fade-up">
          <div class="col-lg-12 d-flex justify-content-center">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-app">Movies</li>
              <li data-filter=".filter-card">Games</li>
              <li data-filter=".filter-web">Mangas/Novels</li>
            </ul>
          </div>
        </div>

        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="100">

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="https://preview.redd.it/would-you-be-up-to-a-star-wars-reboot-v0-bckhazhsx8vb1.jpg?width=1080&crop=smart&auto=webp&s=6eff103202ee31e6813737cc2d1dfea218af5c08" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="https://preview.redd.it/would-you-be-up-to-a-star-wars-reboot-v0-bckhazhsx8vb1.jpg?width=1080&crop=smart&auto=webp&s=6eff103202ee31e6813737cc2d1dfea218af5c08" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Star Wars is an American epic space opera media franchise created by George Lucas, which began with the eponymous 1977 film and quickly became a worldwide pop culture phenomenon. "><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="https://i.ytimg.com/vi/5L6bHNYyh6I/maxresdefault.jpg" class="img-fluid" alt="Monster">
              <div class="portfolio-links">
                <a href="https://i.ytimg.com/vi/5L6bHNYyh6I/maxresdefault.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="One of my favorite manga series created by Naoki Urasawa Sensei. The story revolves around Kenzo Tenma, a Japanese surgeon living in Düsseldorf, Germany whose life enters turmoil after he gets himself involved with Johan Liebert, one of his former patients, who is revealed to be a psychopathic serial killer."><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="https://thediscoverer.columbus.edu.co/wp-content/uploads/2023/02/gggg.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="https://thediscoverer.columbus.edu.co/wp-content/uploads/2023/02/gggg.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Interstellar explores the significance of our lives as humans on Earth, the future our children will excitingly live out, and links this to love, the hypothesized bridge that will connect us to them or as the movie so expertly explores, them to us through time."><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="https://www.buff.game/wp-content/uploads/2021/11/clipimage-4.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="https://www.buff.game/wp-content/uploads/2021/11/clipimage-4.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="I have played all of the games that have been published by Riot Games. Whether if it is Valorant, LoL, TFT, etc."><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="https://cdn.mos.cms.futurecdn.net/vZygtNS3pKeH9W5BMhL5k4.jpg" class="img-fluid" alt="3 Body Problems">
              <div class="portfolio-links">
                <a href="https://cdn.mos.cms.futurecdn.net/vZygtNS3pKeH9W5BMhL5k4.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="A mind bending novel by chinese science fiction author Liu Cixin. The series portrays a fictional past, present and future wherein Earth encounters an alien civilization from a nearby system of three sun-like stars orbiting one another, in an example of the three-body problem in orbital mechanics. This novel series will be receiving a netflix adaptation in March 2024."><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-app">
            <div class="portfolio-wrap">
              <img src="https://ntvb.tmsimg.com/assets/p6326_v_h8_be.jpg?w=1280&h=720" class="img-fluid" alt="The Godfather">
              <div class="portfolio-links">
                <a href="https://ntvb.tmsimg.com/assets/p6326_v_h8_be.jpg?w=1280&h=720" data-gallery="portfolioGallery" class="portfolio-lightbox" title="Widely regarded as one of the greatest films of all time, this mob drama, based on Mario Puzo's novel of the same name, focuses on the powerful Italian-American crime family of Don Vito Corleone (Marlon Brando)."><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="https://static.bandainamcoent.eu/high/elden-ring/elden-ring/03-news/elden-ring-101-trailer-thumbnail.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="https://static.bandainamcoent.eu/high/elden-ring/elden-ring/03-news/elden-ring-101-trailer-thumbnail.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="One of my favorite game of all time Elden Ring, published by FromSoftware the creators of the popular Dark Souls franchise. This game will make you quit in your first gameplay."><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-card">
            <div class="portfolio-wrap">
              <img src="https://en.shiftdelete.net/wp-content/uploads/2022/12/FIFA-23.jpg" class="img-fluid" alt="FIFA 23">
              <div class="portfolio-links">
                <a href="https://en.shiftdelete.net/wp-content/uploads/2022/12/FIFA-23.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="As a Football fan myself, I love FIFA games. I played all the previous installments of the game."><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 portfolio-item filter-web">
            <div class="portfolio-wrap">
              <img src="https://m.media-amazon.com/images/I/51C27fYUHOL.jpg" class="img-fluid" alt="">
              <div class="portfolio-links">
                <a href="https://m.media-amazon.com/images/I/51C27fYUHOL.jpg" data-gallery="portfolioGallery" class="portfolio-lightbox" title="A masterpiece created by Takehiko Inoue Sensei. Vagabond is a story of a boy growing up in 17th century Sengoku era Japan, Shinmen Takezou is shunned by the local villagers as a devil child due to his wild and violent nature."><i class="bx bx-plus"></i></a>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Portfolio Section -->



    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
      <div class="container">

        <div class="section-title">
          <h2>Contact</h2>
          <p></p>
        </div>

        <div class="row" data-aos="fade-in">

          <div class="col-lg-5 d-flex align-items-stretch">
            <div class="info">
              <div class="address">
                <i class="bx bx-smile"></i>
                <h4>Good Day!</h4>
                <p>If you have some feedbacks or suggestions, feel free to contact me using the form to the right. <br> <br>Thank you!</p>
              </div>
              
            </div>

          </div>

          <div class="col-lg-7 mt-5 mt-lg-0 d-flex align-items-stretch">
            <form action="forms/contact.php" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="name">Your Name</label>
                  <input type="text" name="name" class="form-control" id="name" required>
                </div>
                <div class="form-group col-md-6">
                  <label for="name">Your Email</label>
                  <input type="email" class="form-control" name="email" id="email" required>
                </div>
              </div>
              <div class="form-group">
                <label for="name">Subject</label>
                <input type="text" class="form-control" name="subject" id="subject" required>
              </div>
              <div class="form-group">
                <label for="name">Message</label>
                <textarea class="form-control" name="message" rows="10" required></textarea>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
                <div class="error-message">Sorry, there was an error sending your message. Please try again later.</div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>2024</span></strong>
      </div>
      <div class="credits">
        <a href="#">Lucas Ramirez</a>
      </div>
    </div>
  </footer><!-- End  Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/typed.js/typed.umd.js"></script>
  <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>