<?php

$hostname = "localhost";
$dbUser = "root";
$dbPassword = "";
$dbname = "log_reg";
$conn = mysqli_connect($hostname, $dbUser, $dbPassword, $dbname);


// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



?>