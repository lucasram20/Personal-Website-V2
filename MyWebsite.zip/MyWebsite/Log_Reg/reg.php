<?php

// Open database connection
require 'database.php';

$errors = array(); // Initialize an array to store potential error messages

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $lastName = $_POST['lastname'] ?? '';
    $firstName = $_POST['firstname'] ?? '';
    $lotBlk = $_POST['lotblk'] ?? '';
    $street = $_POST['street'] ?? '';
    $phaseSubdivision = $_POST['phase'] ?? '';
    $contactNumber = $_POST['contact'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $repeatPassword = $_POST['re_password'] ?? '';

    // Validate required fields
    if (empty($lastName) || empty($firstName) || empty($email) || empty($password) || empty($repeatPassword) || empty($lotBlk) || empty($street) || empty($phaseSubdivision) || empty($contactNumber)) {
        array_push($errors, "All fields are required");
    }

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        array_push($errors, "Email is not valid");
    }

    // Validate password length
    if (strlen($password) < 8) {
        array_push($errors, "Password must be at least 8 characters long");
    }

    // Check if passwords match
    if ($password !== $repeatPassword) {
        array_push($errors, "Passwords do not match");
    }

    // Validate contact number format (example: expect 11 digits)
    if (!preg_match('/^[0-9]{11}$/', $contactNumber)) {
        array_push($errors, "Invalid contact number; must be 11 digits");
    }

    // If there are no errors, proceed with inserting the data into the database
    if (count($errors) == 0) {
        // Prepare an insert statement using MySQLi
        $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Encrypt the password before saving in the database
        $stmt = $conn->prepare("INSERT INTO users (lastname, firstname, lot_blk, street, phase_subdivision, contact, email, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

        // Bind parameters to the prepared statement
        $stmt->bind_param("ssssssss", $lastName, $firstName, $lotBlk, $street, $phaseSubdivision, $contactNumber, $email, $hashed_password);

        // Execute the prepared statement
        if ($stmt->execute()) {
            // Redirect to login page or success page
            header("Location: /MyWebsite/Log_Reg/index.php");
            exit();
        } else {
            array_push($errors, "Error: " . $stmt->error);
        }

        // Close statement
        $stmt->close();
    }
}

// Close database connection
$conn->close();

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>Registration</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link href="assets/img/Logo.png" rel="icon">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/iconic/css/material-design-iconic-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!--===============================================================================================-->
</head>

<body>

    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100">
                <form class="login100-form validate-form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <span class="login100-form-title p-b-26">
                        Register
                    </span>

                    <?php if (!empty($errors)) : ?>
                        <div class="alert alert-danger" role="alert">
                            <?php foreach ($errors as $error) : ?>
                                <?php echo $error . "<br>"; ?>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <div class="wrap-input100 validate-input" data-validate="Enter your last name">
                        <input class="input100" type="text" name="lastname" placeholder="Last Name">
                        <span class="focus-input100"></span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Enter your first name">
                        <input class="input100" type="text" name="firstname" placeholder="First Name">
                        <span class="focus-input100"></span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Enter your address">
                        <input class="input100" type="text" name="lotblk" placeholder="Lot/BLK">
                        <span class="focus-input100"></span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Enter your address">
                        <input class="input100" type="text" name="street" placeholder="Street">
                        <span class="focus-input100"></span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Enter your address">
                        <input class="input100" type="text" name="phase" placeholder="Phase/Subdivision">
                        <span class="focus-input100"></span>
                    </div>

                    <div class="form-group">
                        <select class="input100" id="region"></select>
                        <br /><br />
                        <select class="input100" id="province"></select>
                        <br /><br />
                        <select class="input100" id="city"></select>
                        <br /><br />
                        <select class="input100" id="barangay"></select>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Enter your contact number">
                        <input class="input100" type="tel" name="contact" id="contact" placeholder="Contact Number" required />
                        <span class="focus-input100"></span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Enter your email address">
                        <input class="input100" type="email" name="email" id="email" placeholder="Email Address" />
                        <span class="focus-input100"></span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Enter your password">
                        <input class="input100" type="password" name="password" id="password" placeholder="Password" />
                        <span class="focus-input100"></span>
                        <span class="btn-show-pass">
                            <i class="zmdi zmdi-eye"></i>
                        </span>
                    </div>

                    <div class="wrap-input100 validate-input" data-validate="Repeat your password">
                        <input class="input100" type="password" name="re_password" id="re_password" placeholder="Repeat your password" />
                        <span class="focus-input100"></span>
                        <span class="btn-show-pass">
                            <i class="zmdi zmdi-eye"></i>
                        </span>
                    </div>

                    <div class="container-login100-form-btn">
                        <div class="wrap-login100-form-btn">
                            <div class="login100-form-bgbtn"></div>
                            <button type="submit" class="login100-form-btn">
                                Register
                            </button>
                        </div>
                    </div>
                </form>
                <div class="text-center p-t-115">
                    <span class="txt1">
                        Already have an account?
                    </span>
                    <a class="txt2" href="index.php">
                        Login
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div id="dropDownSelect1"></div>

    <!--===============================================================================================-->
    <script src="vendor/jquery/jquery-3.2.1.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/animsition/js/animsition.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/bootstrap/js/popper.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/select2/select2.min.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/daterangepicker/moment.min.js"></script>
    <script src="vendor/daterangepicker/daterangepicker.js"></script>
    <!--===============================================================================================-->
    <script src="vendor/countdowntime/countdowntime.js"></script>
    <!--===============================================================================================-->
    <script src="js/main.js"></script>
    <!--===============================================================================================-->
    <!-- Load the plugin scripts -->
    <script type="text/javascript" src="api/jquery.ph-locations.js"></script>
    <script type="text/javascript" src="api/jquery.ph-locations-v1.0.3.js"></script>
    <script type="text/javascript">
        var my_handlers = {
            fill_provinces: function () {
                var region_code = $("option:selected", this).data("psgc-code");
                $("#province").ph_locations("fetch_list", [
                    { region_code: region_code },
                ]);
            },
            fill_cities: function () {
                var province_code = $("option:selected", this).data("psgc-code");
                $("#city").ph_locations("fetch_list", [
                    { province_code: province_code },
                ]);
            },
            fill_barangays: function () {
                var city_code = $("option:selected", this).data("psgc-code");
                $("#barangay").ph_locations("fetch_list", [{ city_code: city_code }]);
            },
        };

        $(function () {
            $("#region").on("change", my_handlers.fill_provinces);
            $("#province").on("change", my_handlers.fill_cities);
            $("#city").on("change", my_handlers.fill_barangays);

            $("#region").ph_locations({ location_type: "regions" });
            $("#province").ph_locations({ location_type: "provinces" });
            $("#city").ph_locations({ location_type: "cities" });
            $("#barangay").ph_locations({ location_type: "barangays" });

            $("#region").ph_locations("fetch_list", [{ selected_value: "PHILIPPINES" }]);
            $("#province").ph_locations("fetch_list", [{ selected_value: "PHILIPPINES" }]);
            $("#city").ph_locations("fetch_list", [{ selected_value: "PHILIPPINES" }]);
            $("#barangay").ph_locations("fetch_list", [{ selected_value: "PHILIPPINES" }]);
        });
    </script>

    <script>
        function togglePasswordVisibility(inputId) {
            var input = document.getElementById(inputId);
            var icon = input.nextElementSibling.querySelector('i');
            if (input.type === "password") {
                input.type = "text";
                icon.classList.remove('zmdi-eye');
                icon.classList.add('zmdi-eye-off');
            } else {
                input.type = "password";
                icon.classList.remove('zmdi-eye-off');
                icon.classList.add('zmdi-eye');
            }
        }
    </script>
</body>

</html>
