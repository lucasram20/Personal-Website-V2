<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'autoload.php'; // Path to autoload.php file of PHPMailer

$success_message = '<div class="alert alert-success">Your message has been sent. Thank you!</div>';
$error_message = '<div class="alert alert-danger">Sorry, there was an error sending your message. Please try again later.</div>';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $subject = $_POST["subject"];
    $message = $_POST["message"];
    
    $mail = new PHPMailer(true);
    try {
        //Server settings
        $mail->SMTPDebug = 0; // Set debug output level to 0
        $mail->isSMTP(); // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com'; // Specify main and backup SMTP servers
        $mail->SMTPAuth = true; // Enable SMTP authentication
        $mail->Username = 'manuelram858@gmail.com'; // SMTP username
        $mail->Password = 'iqji yovx bpwa skdg'; // SMTP password
        $mail->SMTPSecure = 'tls'; // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 587; // TCP port to connect to

        //Recipients
        $mail->setFrom($email, $name);
        $mail->addAddress('manuelram858@gmail.com'); // Add a recipient

        //Content
        $mail->isHTML(false); // Set email format to plain text
        $mail->Subject = "Message from $name: $subject";
        
        // Construct message body
        $body = "Name: $name\n";
        $body .= "Email: $email\n\n";
        $body .= "Message:\n$message";
        
        $mail->Body = $body;

        $mail->send();
        echo $success_message;
    } catch (Exception $e) {
        echo $error_message;
    }
}
?>